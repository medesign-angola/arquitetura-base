export const environment = {
  production: true,
  apiBaseUrl: 'https://605a06e2b11aba001745d60c.mockapi.io/api'
};
